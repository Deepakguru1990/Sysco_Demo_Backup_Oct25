var HDWalletProvider = require("truffle-hdwallet-provider");
var mnemonic = "outdoor father modify clever trophy abandon vital feel portion grit evolve twist"; // 12 word mnemonic

module.exports = {

  networks: {
     development: {
     host: "localhost",
     port: 8545,
     network_id: "*", // Match any network id
     from: "0x0bd5EebDC3E53973dDF236D43906C776a5fE3784"
   },
 
aws: {
            provider: () =>
                    new HDWalletProvider(mnemonic, "http://publicelb-test-1077256889.us-east-1.elb.amazonaws.com:8545"),
                          network_id: "*",
                              }
}
};
